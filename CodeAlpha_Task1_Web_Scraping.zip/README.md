# 🕷️ CodeAlpha Task 1 — Web Scraping

## Project Overview
This project demonstrates web scraping using Python. It collects structured book information from **Books to Scrape**, a public sandbox created for practicing web scraping.

The scraper uses **Requests** to download HTML and **BeautifulSoup** to parse the page structure. It handles pagination and creates a custom CSV dataset.

## Data Collected
- Title
- Price (GBP)
- Rating
- Availability
- Product URL

## Technologies
- Python
- Requests
- BeautifulSoup
- Pandas
- Matplotlib
- Seaborn
- Jupyter Notebook

## Project Structure
```text
CodeAlpha_Task1_Web_Scraping/
├── Task_1_Web_Scraping.ipynb
├── scraper.py
├── data/
│   └── books_dataset.csv
├── images/
└── README.md
```

## How to Run
```bash
pip install requests beautifulsoup4 pandas matplotlib seaborn jupyter
```

Then open:
```text
Task_1_Web_Scraping.ipynb
```

Run all cells. The scraper follows the site's pagination and saves the result to:
```text
data/books_dataset.csv
```

## Learning Outcomes
- Understanding HTML structure
- Finding elements with CSS selectors
- Extracting repeated data
- Handling pagination
- Cleaning scraped data
- Creating custom datasets
- Performing basic data analysis

## Ethical Note
This project uses a dedicated web-scraping practice sandbox rather than a commercial website. Requests are intentionally slowed down to avoid unnecessary load.

## Author
**Nisha Nayak**

BCA Student | Aspiring Data Analyst & Web Developer

## CodeAlpha Internship
**Task 1 — Web Scraping**
