import time
import requests
import pandas as pd
from bs4 import BeautifulSoup
from urllib.parse import urljoin

BASE_URL = "https://books.toscrape.com/"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"
}

RATING_MAP = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}

def scrape_books():
    session = requests.Session()
    session.headers.update(HEADERS)

    url = BASE_URL
    records = []
    page = 1

    while url:
        print(f"Scraping page {page}...")
        response = session.get(url, timeout=15)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")

        for book in soup.select("article.product_pod"):
            title = book.select_one("h3 a")["title"].strip()
            price_text = book.select_one(".price_color").get_text(strip=True)
            price = float(price_text.replace("£", "").replace("Â", ""))
            availability = book.select_one(".availability").get_text(" ", strip=True)
            rating_word = next(
                (c for c in book.select_one(".star-rating")["class"]
                 if c != "star-rating"),
                "Unknown"
            )
            rating = RATING_MAP.get(rating_word)
            relative_link = book.select_one("h3 a")["href"]
            product_url = urljoin(url, relative_link)

            records.append({
                "Title": title,
                "Price_GBP": price,
                "Rating": rating,
                "Availability": availability,
                "Product_URL": product_url
            })

        next_link = soup.select_one("li.next a")
        url = urljoin(url, next_link["href"]) if next_link else None
        page += 1
        time.sleep(0.5)

    return pd.DataFrame(records)

if __name__ == "__main__":
    df = scrape_books()
    df.to_csv("data/books_dataset.csv", index=False)
    print(f"\nScraped {len(df)} books.")
    print(df.head())
